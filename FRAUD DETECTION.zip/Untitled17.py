#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# In[3]:


fd = pd.read_csv(r"C:\Users\NITU\Downloads\Credit_Card_Applications.csv")


# In[4]:


fd


# In[5]:


from sklearn.model_selection import train_test_split

# Fixing the syntax issues
fd['Class'] = pd.Categorical(fd['Class'], categories=[0, 1]) 
fd = fd.dropna(subset=['Class'])

# Splitting data into features (X) and target (y)
X = fd.drop('Class', axis=1)  # Feature matrix
y = fd['Class']  # Target variable

# Train-test-validation split
X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.3, stratify=y, random_state=42
)

X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=42
)

# Printing shapes
print("Train shape (X_train):", X_train.shape)
print("Train shape (y_train):", y_train.shape)
print("Validation shape (X_val):", X_val.shape)
print("Validation shape (y_val):", y_val.shape)
print("Test shape (X_test):", X_test.shape)
print("Test shape (y_test):", y_test.shape)


# In[6]:


# Assuming 'CustomerID' is the column to be dropped
X_train = X_train.drop('CustomerID', axis=1)
X_val = X_val.drop('CustomerID', axis=1)
X_test = X_test.drop('CustomerID', axis=1)


# In[7]:


import matplotlib
import seaborn as sns
import matplotlib.pyplot as plt

# Convert specific columns to 'object' type
X['A8'] = X['A8'].astype('object')
X['A12'] = X['A12'].astype('object')

# Get unique classes and number of classes
unique_classes = fd['Class'].unique()
num_classes = len(unique_classes)

# Get the colormap
colors = matplotlib.colormaps['viridis'].resampled(num_classes).colors

# Visualizing each feature
for feature in X.columns:
    if feature == 'CustomerID':  # Skip 'CustomerID' column
        continue

    if feature in ('A8', 'A12') or X[feature].dtype == 'object':  # Categorical features
        plt.figure(figsize=(7, 3))
        sns.countplot(x=feature, hue='Class', data=fd)
        plt.title(f"Distribution of {feature} by Class")
        plt.show()
    else:  # Numerical features
        plt.figure(figsize=(7, 3))
        sns.boxplot(x='Class', y=feature, data=fd)
        plt.title(f"Boxplot of {feature} by Class")
        plt.show()


# In[8]:


X_train.head()


# In[9]:


y_train.head()


# In[10]:


X_train.info()


# In[11]:


X_train.describe()


# In[12]:


import matplotlib.pyplot as plt

# Calculate fraud and legitimate percentages before balancing
fraud_percentage_before = (fd['Class'].value_counts(normalize=True)[1]) * 100
legitimate_percentage_before = (fd['Class'].value_counts(normalize=True)[0]) * 100

# Data for the pie chart
labels = ['Fraud', 'Legitimate']
sizes = [fraud_percentage_before, legitimate_percentage_before]
colors = ['#ff9999', '#66b3ff']  # Light red for Fraud, Light blue for Legitimate
explode = (0.1, 0)  # Explode the Fraud slice

# Create the pie chart
plt.figure(figsize=(8, 6))
plt.pie(
    sizes,
    labels=labels,
    colors=colors,
    explode=explode,
    autopct='%1.1f%%',
    startangle=140
)
plt.axis('equal')  # Equal aspect ratio ensures the pie chart is a circle
plt.title('Distribution of Fraudulent and Legitimate Transactions (Before Balancing)')
plt.show()


# In[13]:


class_counts = y_train.value_counts()
print(class_counts)


# In[14]:


from sklearn.preprocessing import PolynomialFeatures

# Create interaction feature between A2 and A3
X_train['A2_A3_interaction'] = X_train['A2'].values * X_train['A3'].values
X_val['A2_A3_interaction'] = X_val['A2'].values * X_val['A3'].values
X_test['A2_A3_interaction'] = X_test['A2'].values * X_test['A3'].values

# Create polynomial features for A2 and A3
poly = PolynomialFeatures(degree=2, include_bias=False)

# Fit on the training data and transform the data
poly.fit(X_train[['A2', 'A3']])
poly_features_train = poly.transform(X_train[['A2', 'A3']])
poly_features_val = poly.transform(X_val[['A2', 'A3']])
poly_features_test = poly.transform(X_test[['A2', 'A3']])

# Get feature names after fitting the polynomial transformer
feature_names = poly.get_feature_names_out(X_train[['A2', 'A3']].columns)

# Convert the polynomial features to DataFrames
poly_df_train = pd.DataFrame(poly_features_train, columns=feature_names, index=X_train.index)
poly_df_val = pd.DataFrame(poly_features_val, columns=feature_names, index=X_val.index)
poly_df_test = pd.DataFrame(poly_features_test, columns=feature_names, index=X_test.index)

# Concatenate polynomial features with the original data
X_train = pd.concat([X_train, poly_df_train], axis=1)
X_val = pd.concat([X_val, poly_df_val], axis=1)
X_test = pd.concat([X_test, poly_df_test], axis=1)


# In[15]:


# Create interaction features
X_train['A2_A3_interaction'] = X_train['A2'].values * X_train['A3'].values # Access
X_val['A2_A3_interaction'] = X_val['A2'].values * X_val['A3'].values
X_test['A2_A3_interaction'] = X_test['A2'].values * X_test['A3'].values
# Create polynomial features
poly = PolynomialFeatures(degree=2, include_bias=False)
# Fit on the columns used for polynomial features
poly.fit(X_train[['A2', 'A3']])
poly_features_train = poly.transform(X_train[['A2', 'A3']]) poly_features_val =
poly.transform(X_val[['A2', 'A3']])
poly_features_test = poly.transform(X_test[['A2', 'A3']])
# Get feature names after fitting
feature_names = poly.get_feature_names_out(X_train[['A2', 'A3']].columns)
poly_df_train = pd.DataFrame(poly_features_train, columns=feature_names,
index=X_tr poly_df_val = pd.DataFrame(poly_features_val, columns=feature_names,
i n d e x = X _ v a l . i n p o l y _ d f _ t e s t = p d . D a t a F r a m e ( p o l y _ f e a t u r e s _ t e s t ,
columns=feature_names, index=X_test
X_train = pd.concat([X_train, poly_df_train], axis=1) X_val =
pd.concat([X_val, poly_df_val], axis=1)
X_test = pd.concat([X_test, poly_df_test], axis=1)


# In[16]:


from sklearn.preprocessing import RobustScaler

# Initialize the scaler
scaler = RobustScaler()

# Select numerical features from X_train
numerical_features = X_train.select_dtypes(include=['number']).columns

# Apply RobustScaler to numerical features for each dataset
X_train[numerical_features] = scaler.fit_transform(X_train[numerical_features])
X_val[numerical_features] = scaler.transform(X_val[numerical_features])
X_test[numerical_features] = scaler.transform(X_test[numerical_features])


# In[18]:


# Print the value counts of the balanced y_train
print(y_train_balanced.value_counts())


# In[22]:


import matplotlib.pyplot as plt

# Get class counts after balancing
class_counts_balanced = y_train_balanced.value_counts()

# Data for the pie chart
labels = ['Fraud', 'Legitimate']
sizes = [class_counts_balanced[1], class_counts_balanced[0]]
colors = ['#ff9999', '#66b3ff']  # Light red for Fraud, Light blue for Legitimate

explode = (0.1, 0)  # Explode the Fraud slice

# Create and display the pie chart
plt.pie(sizes, labels=labels, colors=colors, explode=explode, autopct='%1.1f%%', startangle=140)
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
plt.title('Distribution of Fraudulent and Legitimate Transactions (After Balancing)')
plt.show()


# In[23]:


from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix


# In[24]:


dt=DecisionTreeClassifier()
dt.fit(X_train_balanced,y_train_balanced)
y_pred = dt.predict(X_val_balanced)
# Calculate accuracy on the training data
train_accuracy = dt.score(X_train_balanced, y_train_balanced) 
# Calculate accuracy on the validation data
val_accuracy = accuracy_score(y_val_balanced,y_pred)
# Print the results
print("Accuracy in training data:", train_accuracy)
print(f"Accuracy in validation data: {val_accuracy}")
print("Classification Report:\n", classification_report(y_val_balanced, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_val_balanced,y_pred))


# In[25]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# Initialize the Random Forest Classifier
rf = RandomForestClassifier()

# Fit the model on the balanced training data
rf.fit(X_train_balanced, y_train_balanced)

# Predict on the validation data
y_pred = rf.predict(X_val_balanced)

# Calculate accuracy on the training data
train_accuracy = rf.score(X_train_balanced, y_train_balanced)

# Calculate accuracy on the validation data
val_accuracy = accuracy_score(y_val_balanced, y_pred)

# Print the results
print("Accuracy in training data:", train_accuracy)
print(f"Accuracy in validation data: {val_accuracy}")
print("Classification Report:\n", classification_report(y_val_balanced, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_val_balanced, y_pred))


# In[26]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score, classification_report, confusion_matrix

# Define the hyperparameter grid
param_grid = {
    'n_estimators': [100, 200, 300, 400, 500],
    'max_depth': [None, 5, 10, 15, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2', None],
    'bootstrap': [True, False]
}

# Create a Random Forest classifier
rf_classifier = RandomForestClassifier(random_state=42)

# Create RandomizedSearchCV object
random_search = RandomizedSearchCV(
    estimator=rf_classifier,
    param_distributions=param_grid,
    n_iter=10,  # Number of random combinations to try
    scoring='f1',  # Use F1-score for evaluation (you can change this)
    cv=5,  # 5-fold cross-validation
    verbose=2,
    random_state=42,
    n_jobs=-1  # Use all available CPU cores
)

# Fit the RandomizedSearchCV to the training data
random_search.fit(X_train_balanced, y_train_balanced)

# Get the best hyperparameters
best_params = random_search.best_params_
print("Best Hyperparameters:", best_params)

# Get the best model
best_rf_model = random_search.best_estimator_

# Make predictions on the validation set
y_pred = best_rf_model.predict(X_val_balanced)

# Evaluate the model
print("Accuracy:", accuracy_score(y_val_balanced, y_pred))
print("F1-Score:", f1_score(y_val_balanced, y_pred))
print("Precision:", precision_score(y_val_balanced, y_pred))
print("Recall:", recall_score(y_val_balanced, y_pred))
print("ROC AUC:", roc_auc_score(y_val_balanced, y_pred))
print("Classification Report:\n", classification_report(y_val_balanced, y_pred))
print("Confusion Matrix:\n", confusion_matrix(y_val_balanced, y_pred))


# In[30]:


import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc

colors = ["#007bff", "#dc3545"]
sns.set_palette(sns.color_palette(colors))

# Confusion Matrix
y_pred = best_rf_model.predict(X_test_balanced)
cm = confusion_matrix(y_test_balanced, y_pred)

plt.figure(figsize=(7, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", annot_kws={"size": 14})  # Large annotations

plt.title("Confusion Matrix", fontsize=16, fontweight='bold')
plt.xlabel("Predicted Label", fontsize=12)
plt.ylabel("True Label", fontsize=12)
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.show()


# In[31]:


print(classification_report(y_test_balanced, y_pred))  # No visual changes needed here


# In[32]:


# ROC Curve
y_prob = best_rf_model.predict_proba(X_test_balanced)[:, 1]
fpr, tpr, thresholds = roc_curve(y_test_balanced, y_prob)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7, 5))
plt.plot(fpr, tpr, color="darkorange", lw=2, label="ROC curve (area = %0.2f)" % roc_auc)
plt.plot([0, 1], [0, 1], color="navy", lw=2, linestyle="--")
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel("False Positive Rate", fontsize=12)
plt.ylabel("True Positive Rate", fontsize=12)
plt.title("Receiver Operating Characteristic (ROC)", fontsize=16, fontweight='bold')
plt.legend(loc="lower right", fontsize=10)
plt.show()


# In[33]:


# Feature Importance
feature_importances = best_rf_model.feature_importances_
features = X_train_balanced.columns

plt.figure(figsize=(8, 4))
plt.barh(features, feature_importances, color="#007bff")  # Blue bars
plt.xlabel("Feature Importance", fontsize=12)
plt.ylabel("Features", fontsize=12)
plt.title("Feature Importance Plot", fontsize=16, fontweight='bold')
plt.xticks(fontsize=10)
plt.yticks(fontsize=10)
plt.show()


# In[34]:


X_train_reset = X_train_balanced.reset_index(drop=True)


# In[35]:


import pandas as pd

# Generate predictions on the balanced training data
predictions = best_rf_model.predict(X_train_balanced)

# Create a DataFrame with predictions and actual values
results_df = pd.DataFrame({'Prediction': predictions, 'Actual': y_train_balanced})
results_df = results_df.reset_index(drop=True)

# Print predictions with labels
for index, row in results_df.iterrows():
    prediction = row['Prediction']
    actual = row['Actual']
    if prediction == 1:
        prediction_label = "Fraud"
    else:
        prediction_label = "Legitimate"
    print(f"Index: {index}, Prediction: {prediction_label}, Actual: {actual}")


# In[36]:


accuracy = accuracy_score(y_train_balanced, predictions)
print(f"Accuracy: {accuracy * 100:.2f}%")


# In[37]:


X_test_reset = X_test.reset_index(drop=True)


# In[38]:


import pandas as pd

# Generate predictions on the balanced test data
predictions = best_rf_model.predict(X_test_balanced)

# Create a DataFrame with predictions and actual values
results_df = pd.DataFrame({'Prediction': predictions, 'Actual': y_test_balanced})
results_df = results_df.reset_index(drop=True)

# Print predictions with labels
for index, row in results_df.iterrows():
    prediction = row['Prediction']
    actual = row['Actual']
    if prediction == 1:
        prediction_label = "Fraud"
    else:
        prediction_label = "Legitimate"
    print(f"Index: {index}, Prediction: {prediction_label}, Actual: {actual}")


# In[39]:


class_counts = y_test_balanced.value_counts()
print("Legitimate Transactions:", class_counts[0])
print("Fraudulent Transactions:",class_counts[1])


# In[40]:


accuracy = accuracy_score(y_test_balanced, predictions)
print(f"Accuracy: {accuracy * 100:.2f}%")


# In[ ]:




